package com.example.practica1login20_0104;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        EditText Input = findViewById(R.id.userName);
        EditText Input2 = findViewById(R.id.password000);

        Button Login = findViewById(R.id.button);
        Button ClearAll = findViewById(R.id.button2);

        Login.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String User = Input.getText().toString();
                String Password = Input2.getText().toString();
                if(User.equals("admin") && Password.equals("admin123")){
                    ingresar();
                    Toast.makeText(getApplicationContext(), "Correcto", Toast.LENGTH_SHORT).show();
                }
                else{
                    Toast.makeText(getApplicationContext(), "Incorrecto", Toast.LENGTH_SHORT).show();
                }
            }
        });

        ClearAll.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View v) {
                String texto1 = Input.getText().toString();
                String texto2 = Input2.getText().toString();

                if(texto1.isEmpty() && texto2.isEmpty()){
                    Toast.makeText(getApplicationContext(), "Contenido vaciado", Toast.LENGTH_SHORT).show();
                }
                else{
                    Input.setText("");
                    Input2.setText("");
                }
            }
        });
    }

    public void ingresar(){
        Intent i = new Intent(this, MainActivity2.class);
        startActivity(i);
    }

}